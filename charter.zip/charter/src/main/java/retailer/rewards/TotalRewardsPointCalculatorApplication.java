package retailer.rewards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TotalRewardsPointCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TotalRewardsPointCalculatorApplication.class, args);
	}

}
