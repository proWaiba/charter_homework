package retailer.rewards.constants;

public class RewardConstants {
    public static final int MONTH = 30;
    public static int LIMIT = 50;
    public static int SECOND_LIMIT = 100;
}
